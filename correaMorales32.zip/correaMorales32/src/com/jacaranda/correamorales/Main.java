package com.jacaranda.correamorales;

import java.util.Scanner;

public class Main {
	public static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Usuario nuevo;

	}
}
