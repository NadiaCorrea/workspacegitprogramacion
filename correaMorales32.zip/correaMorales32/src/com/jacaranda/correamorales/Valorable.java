package com.jacaranda.correamorales;

public interface Valorable {

	public boolean valorar(String valoracion);

}
